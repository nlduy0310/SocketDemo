import * as React from "react";

function IconBoxMultiple4({
  size = 24,
  color = "currentColor",
  stroke = 2,
  ...props
}) {
  return <svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-box-multiple-4" width={size} height={size} viewBox="0 0 24 24" strokeWidth={stroke} stroke={color} fill="none" strokeLinecap="round" strokeLinejoin="round" {...props}><desc>{"Download more icon variants from https://tabler-icons.io/i/box-multiple-4"}</desc><path stroke="none" d="M0 0h24v24H0z" fill="none" /><rect x={7} y={3} width={14} height={14} rx={2} /><path d="M17 17v2a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h2" /><path d="M15 14v-8l-4 6h5" /></svg>;
}

export default IconBoxMultiple4;